var level2unlock = false;
var level3unlock = false;

var fireTowers;
var waterTowers;
var windTowers;
var iceTowers;
var elecTowers;
var enemies;
var enemies2;
var enemies3;
var enemies4;
var enemies5;
var enemies6;
var enemies7;
var enemies8;
var enemies9;
var bullets;
var rocks;
var rocks2;
var rocks3;
var rocks4;
var rocks5;
var trees;
var trees2;
var trees3;

var curBut ='None';

var goldText;
var gameGold = 10;
var livesText;
var lives = 10;
var waveText;

var FIRECOST = 3; //3
var WATERCOST = 4; // 4
var WINDCOST = 12; // 15
var ICECOST = 10; // 9
var ELECCOST = 6; // 6

var FIRETINT = '0xFF5050';
var WATERTINT = '0x508DFF';
var ICETINT = '0x00FFE8';
var ELECTINT = '0xFFF450';

var path;

var pointsX = [];
var pointsY = [];

var curWave = 1;

var wave1 = 20;
var wave2 = 30;
var wave3 = 30;
var wave4 = 20;
var wave5 = 25;
var wave6 = 25;
var wave7 = 40;
var wave8 = 30;
var wave9 = 45;
var wave10 = 50;